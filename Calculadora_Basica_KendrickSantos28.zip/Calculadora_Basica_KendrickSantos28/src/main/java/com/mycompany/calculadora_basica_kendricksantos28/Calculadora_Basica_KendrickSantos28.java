/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora_basica_kendricksantos28;

/**
 *
 * @author LABORATORIO
 */
public class Calculadora_Basica_KendrickSantos28 {

    public static void main(String[] args) {
        Cal a = new Cal();
        a.setVisible(true);
    }
}
